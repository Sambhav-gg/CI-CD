import https from 'https';
import http from 'http';
import { SNSClient, PublishCommand } from '@aws-sdk/client-sns';

const sns = new SNSClient({ region: process.env.AWS_REGION_ID ?? 'eu-north-1' });

export const handler = async () => {
    const url = `http://${process.env.ALB_DNS}/check`;

    try {
        await checkUrl(url);
        console.log('Health check passed:', url);
        return { status: 'ok' };
    } catch (err) {
        console.error('Health check failed:', err.message);

        await sns.send(new PublishCommand({
            TopicArn: process.env.SNS_TOPIC_ARN,
            Subject: 'App is DOWN',
            Message: `
Health check failed for: ${url}
Error: ${err.message}
Time:  ${new Date().toISOString()}

Check your EC2 and Docker container immediately.
            `.trim()
        }));

        return { status: 'down', error: err.message };
    }
};

function checkUrl(url) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        const req = client.get(url, { timeout: 5000 }, (res) => {
            if (res.statusCode === 200) {
                resolve(res.statusCode);
            } else {
                reject(new Error(`Status code: ${res.statusCode}`));
            }
        });
        req.on('error', reject);
        req.on('timeout', () => reject(new Error('Request timed out')));
        req.end();
    });
}